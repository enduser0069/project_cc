function MainPage() {
  return (
    <>
      <p>A Twitter Clone</p>
      <footer>Copyright &copy; 2022 Chirper</footer>
    </>
  );
}

export default MainPage;